#include <opencv2/opencv.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
using namespace cv;
using namespace std;
int main(int argc, char** argv)
{
    // ��������ͼ��
    vector<Mat> test_data;
    for (int i = 0; i <= 29; i++)
    {
        string filename = "E:/svm/test_data/" + to_string(i) + ".png";

        Mat img = imread(filename, IMREAD_GRAYSCALE);
        test_data.push_back(img);
    }
    // ����ѵ������
    Mat trainData(30, 48 * 80, CV_32FC1);
    for (int i = 0; i < test_data.size(); i++)
    {
        Mat img = test_data[i];
        resize(img, img, Size(48, 80));
        Mat(1, 48 * 80, CV_32F, img.data).copyTo(trainData.row(i));
    }
    // ���ɱ�ǩ����
    Mat labels(30, 1, CV_32SC1);
    for (int i = 0; i < labels.rows; i++)
    {
        if (i < 20)
            labels.at<int>(i, 0) = 1; // ǰ10��ͼ��Ϊ0����ǩΪ1
        else
            labels.at<int>(i, 0) = 0; // ��10��ͼ��Ϊ1����ǩΪ0
    }
    // ѵ��SVMģ��
    Ptr<ml::SVM> svm = ml::SVM::create();
    svm->setType(ml::SVM::C_SVC);
    svm->setKernel(ml::SVM::LINEAR);
    svm->setTermCriteria(TermCriteria(TermCriteria::MAX_ITER, 100, 1e-6));
    svm->train(trainData, ml::ROW_SAMPLE, labels);
    // ����SVMģ��
    svm->save("E:/svm/digit_svm_model.xml");
    return 0;
}