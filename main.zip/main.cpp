#include <opencv2/opencv.hpp>
#include <iostream>
#include<string>
#include <opencv2/ml.hpp>
using namespace std;
using namespace cv;
using namespace cv::ml;

int main()
{
	int result = 0;
	int number = 10;
	Ptr<SVM> svm = SVM::load("svm.xml");//����svm����

	string filePath = "E:\\data\\train_image\\";
	for (int i = 0; i < number; i++)
	{
		stringstream ss;
		// ������ַ������� ss ��
		ss << filePath << "0\\" << i << ".png";
		string files = ss.str();
		ss.str("");//���ss
		Mat inMat = imread(files);
		Mat p = inMat.reshape(1, 1);
		p.convertTo(p, CV_32FC1);
		int response = (int)svm->predict(p);
		if (response == 0)
		{
			result++;
		}
	}

	cout << result << endl;
	getchar();
	return  0;
}


